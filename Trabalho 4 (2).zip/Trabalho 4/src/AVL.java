import java.util.*;

/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Implementação de uma Árvore AVL que implementa a interface Map.
 * Esta implementação permite armazenar objetos do tipo Veiculo indexados por chaves do tipo Integer.
 */
public class AVL implements Map<Integer, Veiculo> {
    private Noh<Integer, Veiculo> raiz;
    private int tamanho;

    /**
     * Construtor da classe AVL.
     * @param tamanho Tamanho inicial da árvore.
     */
    public AVL(int tamanho){
        this.tamanho = tamanho;
        this.raiz = null;
    }

    /**
     * Insere um novo par chave-valor na árvore AVL.
     * @param chave Chave do elemento a ser inserido.
     * @param valor Valor (Veiculo) a ser inserido.
     * @return O valor inserido.
     */
    @Override
    public Veiculo put(Integer chave, Veiculo valor) {
        raiz = inserir(raiz, chave, valor);
        tamanho++;
        return valor;
    }

    /**
     * Método auxiliar recursivo para inserir um novo nó na árvore AVL.
     * @param noh Nó atual onde a inserção será realizada.
     * @param chave Chave do elemento a ser inserido.
     * @param valor Valor (Veiculo) a ser inserido.
     * @return O nó atualizado após a inserção.
     */
    private Noh<Integer, Veiculo> inserir(Noh<Integer, Veiculo> noh, Integer chave, Veiculo valor) {
        if (noh == null) {
            return new Noh<>(chave, valor);
        }
        if (chave < noh.chave) {
            noh.esquerdo = inserir(noh.esquerdo, chave, valor);
        } else if (chave > noh.chave) {
            noh.direito = inserir(noh.direito, chave, valor);
        } else {
            noh.valor = valor;
        }
        noh.altura = 1 + Math.max(altura(noh.esquerdo), altura(noh.direito));
        return balancear(noh);
    }

    /**
     * Realiza o balanceamento da árvore AVL após uma operação de inserção.
     * @param noh Nó atual onde o balanceamento será realizado.
     * @return Nó balanceado.
     */
    private Noh<Integer, Veiculo> balancear(Noh<Integer, Veiculo> noh) {
        int fatorBalanceamento = balanceFactor(noh);

        if (fatorBalanceamento > 1) {
            if (balanceFactor(noh.esquerdo) < 0) {
                noh.esquerdo = rotacaoEsquerda(noh.esquerdo);
            }
            return rotacaoDireita(noh);
        }
        if (fatorBalanceamento < -1) {
            if (balanceFactor(noh.direito) > 0) {
                noh.direito = rotacaoDireita(noh.direito);
            }
            return rotacaoEsquerda(noh);
        }
        return noh;
    }

    /**
     * Calcula o fator de balanceamento de um nó na árvore AVL.
     * @param noh Nó para o qual o fator de balanceamento será calculado.
     * @return Fator de balanceamento do nó.
     */
    private int balanceFactor(Noh<Integer, Veiculo> noh) {
        return altura(noh.esquerdo) - altura(noh.direito);
    }

    /**
     * Realiza uma rotação à direita em torno do nó especificado.
     * @param noh Nó em torno do qual a rotação será realizada.
     * @return Novo nó raiz após a rotação.
     */
    private Noh<Integer, Veiculo> rotacaoDireita(Noh<Integer, Veiculo> noh) {
        Noh<Integer, Veiculo> x = noh.esquerdo;
        noh.esquerdo = x.direito;
        x.direito = noh;
        noh.altura = 1 + Math.max(altura(noh.esquerdo), altura(noh.direito));
        x.altura = 1 + Math.max(altura(x.esquerdo), altura(x.direito));
        return x;
    }

    /**
     * Realiza uma rotação à esquerda em torno do nó especificado.
     * @param noh Nó em torno do qual a rotação será realizada.
     * @return Novo nó raiz após a rotação.
     */
    private Noh<Integer, Veiculo> rotacaoEsquerda(Noh<Integer, Veiculo> noh) {
        Noh<Integer, Veiculo> x = noh.direito;
        noh.direito = x.esquerdo;
        x.esquerdo = noh;
        noh.altura = 1 + Math.max(altura(noh.esquerdo), altura(noh.direito));
        x.altura = 1 + Math.max(altura(x.esquerdo), altura(x.direito));
        return x;
    }

    /**
     * Retorna a altura de um nó na árvore AVL.
     * @param noh Nó para o qual a altura será calculada.
     * @return Altura do nó.
     */
    private int altura(Noh<Integer, Veiculo> noh) {
        return noh == null ? 0 : noh.altura;
    }

    /**
     * Obtém o valor associado à chave especificada na árvore AVL.
     * @param chave Chave cujo valor associado será retornado.
     * @return Valor associado à chave, ou null se a chave não estiver presente na árvore.
     */
    @Override
    public Veiculo get(Object chave) {
        Noh<Integer, Veiculo> noh = buscar(raiz, (Integer) chave);
        return noh != null ? noh.valor : null;
    }

    /**
     * Método auxiliar recursivo para buscar um nó com a chave especificada na árvore AVL.
     * @param noh Nó atual onde a busca será realizada.
     * @param chave Chave a ser buscada.
     * @return Nó com a chave especificada, ou null se a chave não for encontrada.
     */
    private Noh<Integer, Veiculo> buscar(Noh<Integer, Veiculo> noh, Integer chave) {
        if (noh == null || chave.equals(noh.chave)) {
            return noh;
        }
        if (chave < noh.chave) {
            return buscar(noh.esquerdo, chave);
        } else {
            return buscar(noh.direito, chave);
        }
    }

    /**
     * Remove o par chave-valor associado à chave especificada na árvore AVL.
     * @param chave Chave do elemento a ser removido.
     * @return Valor (Veiculo) removido, ou null se a chave não estiver presente na árvore.
     */
    @Override
    public Veiculo remove(Object chave) {
        Noh<Integer, Veiculo>[] resultado = remover(raiz, (Integer) chave);
        raiz = resultado[0];
        if (resultado[1] != null) tamanho--;
        return resultado[1] != null ? resultado[1].valor : null;
    }

    /**
     * Método auxiliar recursivo para remover um nó com a chave especificada na árvore AVL.
     * @param noh Nó atual onde a remoção será realizada.
     * @param chave Chave do elemento a ser removido.
     * @return Array contendo o nó raiz atualizado e o nó removido.
     */
    @SuppressWarnings("unchecked")
    private Noh<Integer, Veiculo>[] remover(Noh<Integer, Veiculo> noh, Integer chave) {
        if (noh == null) return new Noh[] { null, null };

        Noh<Integer, Veiculo>[] resultado;
        if (chave < noh.chave) {
            resultado = remover(noh.esquerdo, chave);
            noh.esquerdo = resultado[0];
        } else if (chave > noh.chave) {
            resultado = remover(noh.direito, chave);
            noh.direito = resultado[0];
        } else {
            if (noh.esquerdo == null) return new Noh[] { noh.direito, noh };
            if (noh.direito == null) return new Noh[] { noh.esquerdo, noh };
            Noh<Integer, Veiculo> temp = noh;
            noh = min(temp.direito);
            noh.direito = deletarMin(temp.direito);
            noh.esquerdo = temp.esquerdo;
            return new Noh[] { noh, temp };
        }
        noh.altura = 1 + Math.max(altura(noh.esquerdo), altura(noh.direito));
        return new Noh[] { balancear(noh), resultado[1] };
    }

    /**
     * Encontra o nó com a menor chave na subárvore especificada.
     * @param noh Nó raiz da subárvore onde a busca será realizada.
     * @return Nó com a menor chave na subárvore.
     */
    private Noh<Integer, Veiculo> min(Noh<Integer, Veiculo> noh) {
        if (noh.esquerdo == null) return noh;
        return min(noh.esquerdo);
    }

    /**
     * Remove o nó com a menor chave na subárvore especificada.
     * @param noh Nó raiz da subárvore onde a remoção será realizada.
     * @return Nó raiz da subárvore atualizada após a remoção.
     */
    private Noh<Integer, Veiculo> deletarMin(Noh<Integer, Veiculo> noh) {
        if (noh.esquerdo == null) return noh.direito;
        noh.esquerdo = deletarMin(noh.esquerdo);
        noh.altura = 1 + Math.max(altura(noh.esquerdo), altura(noh.direito));
        return balancear(noh);
    }

    /**
     * Retorna o número de elementos na árvore AVL.
     * @return Número de elementos na árvore.
     */
    @Override
    public int size() {
        return tamanho;
    }

    /**
     * Verifica se a árvore AVL está vazia.
     * @return true se a árvore estiver vazia, false caso contrário.
     */
    @Override
    public boolean isEmpty() {
        return tamanho == 0;
    }

    /**
     * Verifica se a árvore AVL contém a chave especificada.
     * @param chave Chave a ser verificada.
     * @return true se a árvore contém a chave, false caso contrário.
     */
    @Override
    public boolean containsKey(Object chave) {
        return get(chave) != null;
    }

    /**
     * Verifica se a árvore AVL contém o valor especificado.
     * @param valor Valor a ser verificado.
     * @return true se a árvore contém o valor, false caso contrário.
     */
    @Override
    public boolean containsValue(Object valor) {
        for (Veiculo v : values()) {
            if (v.equals(valor)) return true;
        }
        return false;
    }

    /**
     * Retorna uma coleção contendo todos os valores na árvore AVL.
     * @return Coleção contendo todos os valores na árvore.
     */
    @Override
    public Collection<Veiculo> values() {
        List<Veiculo> values = new ArrayList<>();
        emOrdem(raiz, values);
        return values;
    }

    /**
     * Método auxiliar para percorrer a árvore em ordem.
     * @param noh Nó atual sendo visitado.
     * @param values Lista onde os valores serão armazenados em ordem.
     */
    private void emOrdem(Noh<Integer, Veiculo> noh, List<Veiculo> values) {
        if (noh != null) {
            emOrdem(noh.esquerdo, values);
            values.add(noh.valor);
            emOrdem(noh.direito, values);
        }
    }

    /**
     * Método para imprimir os valores da árvore AVL em ordem.
     */
    public void impressaoEmOrdem() {
        emOrdemImpressao(this.raiz);
    }
    
    /**
     * Método auxiliar para imprimir os valores da árvore AVL em ordem.
     * @param noh Nó atual sendo visitado.
     */
    private void emOrdemImpressao(Noh<Integer, Veiculo> noh) {
        if (noh != null) {
            emOrdemImpressao(noh.esquerdo);
            System.out.println(noh.valor);
            emOrdemImpressao(noh.direito);
        }
    }

    @Override
    public void putAll(Map<? extends Integer, ? extends Veiculo> mapa) {
        throw new UnsupportedOperationException("Não implementado");
    }

    /**
     * Remove todos os elementos da árvore AVL.
     */
    @Override
    public void clear() {
        raiz = null;
        tamanho = 0;
    }

    @Override
    public Set<Entry<Integer, Veiculo>> entrySet() {
        throw new UnsupportedOperationException("Não implementado");
    }

    @Override
    public Set<Integer> keySet() {
        throw new UnsupportedOperationException("Não implementado");
    }
}