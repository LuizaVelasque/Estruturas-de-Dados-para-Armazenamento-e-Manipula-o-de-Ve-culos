/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Classe que representa um nó em uma árvore.
 *
 * @param <K> tipo da chave do nó, deve ser comparável
 * @param <V> tipo do valor associado à chave
 */
public class Noh<K extends Comparable<K>, V> {
    K chave;
    V valor;
    Noh<K, V> esquerdo;
    Noh<K, V> direito;
    int altura;  // no caso de avl

     /**
     * Construtor para criar um novo nó com chave e valor especificados.
     *
     * @param chave a chave associada ao nó
     * @param valor o valor associado à chave
     */
    public Noh(K chave, V valor) {
        this.chave = chave;
        this.valor = valor;
        this.esquerdo = null;
        this.direito = null;
        this.altura = 1; 
    }
    
    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
}