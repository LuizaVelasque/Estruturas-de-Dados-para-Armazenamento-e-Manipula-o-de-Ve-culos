import java.util.*;

/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Implementação de um Map utilizando um vetor ordenado para armazenar os dados.
 * Esta implementação utiliza um vetor de entradas para armazenar pares chave-valor,
 * mantendo as chaves ordenadas em ordem crescente.
 */
public class VetorOrdenado implements Map<Integer, Veiculo> {
    /**
     * Classe interna que representa uma entrada no vetor.
     *
     * @param <K> tipo da chave da entrada
     * @param <V> tipo do valor da entrada
     */
    private static class Entry<K, V> {
        private K key;     // Chave da entrada
        private V value;   // Valor associado à chave

        /**
         * Construtor para criar uma nova entrada com chave e valor especificados.
         *
         * @param key a chave da entrada
         * @param value o valor associado à chave
         */
        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        /**
         * Obtém a chave da entrada.
         *
         * @return a chave da entrada
         */
        public K getKey() {
            return key;
        }

        /**
         * Obtém o valor associado à chave da entrada.
         *
         * @return o valor associado à chave
         */
        public V getValue() {
            return value;
        }

        /**
         * Define o valor associado à chave da entrada.
         *
         * @param value o novo valor a ser associado à chave
         */
        public void setValue(V value) {
            this.value = value;
        }
    }

    private Entry<Integer, Veiculo>[] vetor;   // Vetor de entradas
    private int tamanho;    // Tamanho atual do vetor

    /**
     * Construtor para criar um VetorOrdenado com a capacidade especificada.
     *
     * @param capacidade a capacidade inicial do vetor
     */
    @SuppressWarnings("unchecked")
    public VetorOrdenado(int capacidade) {
        this.vetor = new Entry[capacidade];
        this.tamanho = 0;
    }

    /**
     * Retorna o número de elementos no vetor.
     *
     * @return o número de elementos no vetor
     */
    @Override
    public int size() {
        return tamanho;
    }

    /**
     * Verifica se o vetor está vazio.
     *
     * @return true se o vetor estiver vazio, false caso contrário
     */
    @Override
    public boolean isEmpty() {
        return tamanho == 0;
    }

    /**
     * Verifica se o vetor contém a chave especificada.
     *
     * @param key a chave cuja presença no vetor será verificada
     * @return true se o vetor contiver a chave especificada, false caso contrário
     */
    @Override
    public boolean containsKey(Object key) {
        for (int i = 0; i < tamanho; i++) {
            if (Objects.equals(vetor[i].getKey(), key)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Verifica se o vetor contém o valor especificado.
     *
     * @param value o valor cuja presença no vetor será verificada
     * @return true se o vetor contiver o valor especificado, false caso contrário
     */
    @Override
    public boolean containsValue(Object value) {
        for (int i = 0; i < tamanho; i++) {
            if (Objects.equals(vetor[i].getValue(), value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Obtém o valor associado à chave especificada no vetor.
     *
     * @param key a chave cujo valor associado será retornado
     * @return o valor associado à chave especificada, ou null se a chave não estiver no vetor
     */
    @Override
    public Veiculo get(Object key) {
        for (int i = 0; i < tamanho; i++) {
            if (Objects.equals(vetor[i].getKey(), key)) {
                return vetor[i].getValue();
            }
        }
        return null;
    }

    /**
     * Insere um par chave-valor no vetor ordenado.
     *
     * @param key a chave a ser inserida
     * @param value o valor associado à chave a ser inserido
     * @return o valor anterior associado à chave, ou null se a chave não existia no vetor
     */
    @Override
    public Veiculo put(Integer key, Veiculo value) {
        Entry<Integer, Veiculo> newEntry = new Entry<>(key, value);
        int posicao = encontrarPosicaoParaInserir(key);
        for (int i = tamanho - 1; i >= posicao; i--) {
            vetor[i + 1] = vetor[i];
        }
        vetor[posicao] = newEntry;
        tamanho++;
        return value;
    }

    /**
     * Remove a chave especificada do vetor.
     *
     * @param key a chave a ser removida
     * @return o valor associado à chave removida, ou null se a chave não estiver no vetor
     */
    @Override
    public Veiculo remove(Object key) {
        int indice = buscarIndice((Integer) key);
        if (indice == -1) {
            return null;
        }
        Veiculo valorRemovido = vetor[indice].getValue();
        for (int i = indice; i < tamanho - 1; i++) {
            vetor[i] = vetor[i + 1];
        }
        tamanho--;
        return valorRemovido;
    }

    /**
     * Remove todos os elementos do vetor.
     */
    @SuppressWarnings("unchecked")
    @Override
    public void clear() {
        vetor = new Entry[vetor.length];
        tamanho = 0;
    }

    /**
     * Busca o índice da chave especificada no vetor.
     *
     * @param chave a chave cujo índice será buscado
     * @return o índice da chave no vetor, ou -1 se a chave não estiver no vetor
     */
    private int buscarIndice(Integer chave) {
        for (int i = 0; i < tamanho; i++) {
            if (Objects.equals(vetor[i].getKey(), chave)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Encontra a posição correta para inserir a chave no vetor ordenado.
     *
     * @param chave a chave a ser inserida
     * @return a posição onde a chave deve ser inserida para manter a ordem
     */
    private int encontrarPosicaoParaInserir(Integer chave) {
        int posicao;
        for (posicao = 0; posicao < tamanho; posicao++) {
            if (chave.compareTo(vetor[posicao].getKey()) < 0) {
                break;
            }
        }
        return posicao;
    }

    /**
     * Retorna uma coleção contendo todos os valores no vetor.
     *
     * @return uma coleção contendo todos os valores no vetor
     */
    @Override
    public Collection<Veiculo> values() {
        List<Veiculo> valores = new ArrayList<>();
        for (int i = 0; i < tamanho; i++) {
            valores.add(vetor[i].getValue());
        }
        return valores;
    }

    /**
     * Imprime os valores no vetor em ordem de chave crescente.
     */
    public void impressaoEmOrdem() {
        for (int i = 0; i < tamanho; i++) {
            System.out.println(vetor[i].getValue());
        }
    }

    @Override
    public void putAll(Map<? extends Integer, ? extends Veiculo> m) {
        throw new UnsupportedOperationException("Operação não suportada");
    }

    @Override
    public Set<Integer> keySet() {
        throw new UnsupportedOperationException("Operação não suportada");
    }

    @Override
    public Set<Map.Entry<Integer, Veiculo>> entrySet() {
        throw new UnsupportedOperationException("Operação não suportada");
    }
}