import java.io.IOException;
import java.util.Scanner;

/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Classe principal que realiza testes de desempenho e interação com estruturas de dados para armazenar veículos.
 */
public class Main {

    /**
     * Método principal que inicia o programa, limpando o terminal e exibindo o menu.
     *
     * @param args argumentos da linha de comando (não utilizado)
     * @throws InterruptedException exceção lançada em caso de interrupção durante a espera
     */
    public static void main(String[] args) throws InterruptedException {
        limparTerminal();
        exibirMenu();
    }

    /**
     * Exibe o menu principal e gerencia as opções selecionadas pelo usuário.
     *
     * @throws InterruptedException exceção lançada em caso de interrupção durante a espera
     */
    public static void exibirMenu() throws InterruptedException {
        int escolha;
        boolean continuar = true;
        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("\nEscolha uma das estruturas:");
            System.out.println("\u001B[34m1.\u001B[0m Vetor Ordenado");
            System.out.println("\u001B[34m2.\u001B[0m ABB");
            System.out.println("\u001B[34m3.\u001B[0m AVL");
            System.out.println("\u001B[31m0.\u001B[0m Sair");
            escolha = scanner.nextInt();
            limparTerminal();

            switch (escolha) {
                case 1:
                    System.out.println("Informe a quantia de veículos desejados: ");
                    int tamanhoVetor = scanner.nextInt();
                    limparTerminal();
                    testarTodasEstruturasVetorOrdenado(tamanhoVetor);
                    break;
                case 2:
                    System.out.println("Informe a quantia de veículos desejados: ");
                    int tamanhoABB = scanner.nextInt();
                    limparTerminal();
                    testarTodasEstruturasABB(tamanhoABB);
                    break;
                case 3:
                    System.out.println("Informe a quantia de veículos desejados: ");
                    int tamanhoAVL = scanner.nextInt();
                    limparTerminal();
                    testarTodasEstruturasAVL(tamanhoAVL);
                    break;
                case 0:
                    System.out.println("\u001B[31mSaindo do programa...\u001B[0m");
                    continuar = false;
                    Thread.sleep(1000);
                    limparTerminal();
                    break;
                default:
                    System.out.println("\u001B[31mOpção inválida. Por favor, escolha novamente.\u001B[0m");
            }
        } while (continuar);

        scanner.close();
    }

    /**
     * Limpa o terminal de acordo com o sistema operacional detectado.
     */
    public static void limparTerminal() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (Exception e) {
            System.out.println("Erro ao tentar limpar o terminal: " + e.getMessage());
        }
    }

    /**
     * Solicita que o usuário pressione qualquer tecla para retornar ao menu anterior.
     */
    public static void retornar() {
        System.out.println("\u001B[92mPressione qualquer tecla para voltar ao menu anterior...\u001B[0m");
        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        limparTerminal();
    }

    /**
     * Realiza testes em todas as operações disponíveis para a estrutura de Vetor Ordenado.
     *
     * @param tamanho quantidade de veículos a serem inseridos na estrutura
     */
    public static void testarTodasEstruturasVetorOrdenado(int tamanho) {
        VetorOrdenado vetorOrdenado = new VetorOrdenado(tamanho);
        testarEstruturaInsercaoVetorOrdenado(vetorOrdenado, tamanho);
        System.out.println("");
        testarImpressaoPorOrdemChassiVetor(vetorOrdenado);
        System.out.println("");
        testarContagemVeiculosFordVetor(vetorOrdenado);
        System.out.println("");
        testarRemocaoVeiculosChassiVetor(vetorOrdenado);
        System.out.println("");
        retornar();
    }

    /**
     * Realiza testes em todas as operações disponíveis para a estrutura de Árvore Binária de Busca (ABB).
     *
     * @param tamanho quantidade de veículos a serem inseridos na estrutura
     */
    public static void testarTodasEstruturasABB(int tamanho) {
        ABB abb = new ABB(tamanho);
        testarEstruturaInsercaoABB(abb, tamanho);
        System.out.println("");
        testarImpressaoPorOrdemChassiABB(abb);
        System.out.println("");
        testarContagemVeiculosFordABB(abb);
        System.out.println("");
        testarRemocaoVeiculosChassiABB(abb);
        System.out.println("");
        retornar();
    }

    /**
     * Realiza testes em todas as operações disponíveis para a estrutura de Árvore AVL.
     *
     * @param tamanho quantidade de veículos a serem inseridos na estrutura
     */
    public static void testarTodasEstruturasAVL(int tamanho) {
        AVL avl = new AVL(tamanho);
        testarEstruturaInsercaoAVL(avl, tamanho);
        System.out.println("");
        testarImpressaoPorOrdemChassiAVL(avl);
        System.out.println("");
        testarContagemVeiculosFordAVL(avl);
        System.out.println("");
        testarRemocaoVeiculosChassiAVL(avl);
        System.out.println("");
        retornar();
    }

    /**
     * Testa a operação de inserção de veículos em uma estrutura de Vetor Ordenado.
     *
     * @param vetor estrutura de Vetor Ordenado a ser testada
     * @param quantia_veiculos quantidade de veículos a serem inseridos
     */
    public static void testarEstruturaInsercaoVetorOrdenado(VetorOrdenado vetor, int quantia_veiculos) {
        long tempoInicio = System.nanoTime();
        for (int i = 0; i < quantia_veiculos; i++) {
            Veiculo veiculo = new Veiculo();
            vetor.put(veiculo.getChassi(), veiculo);
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para inserir " + quantia_veiculos + " veículos em uma estrutura de Vetor Ordenado:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de inserção de veículos em uma estrutura de Árvore Binária de Busca (ABB).
     *
     * @param abb estrutura de Árvore Binária de Busca a ser testada
     * @param quantia_veiculos quantidade de veículos a serem inseridos
     */
    public static void testarEstruturaInsercaoABB(ABB abb, int quantia_veiculos) {
        long tempoInicio = System.nanoTime();
        for (int i = 0; i < quantia_veiculos; i++) {
            Veiculo veiculo = new Veiculo();
            abb.put(veiculo.getChassi(), veiculo);
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para inserir " + quantia_veiculos + " veículos em uma estrutura de Árvore Binária de Busca:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de inserção de veículos em uma estrutura de Árvore AVL.
     *
     * @param avl estrutura de Árvore AVL a ser testada
     * @param quantia_veiculos quantidade de veículos a serem inseridos
     */
    public static void testarEstruturaInsercaoAVL(AVL avl, int quantia_veiculos) {
        long tempoInicio = System.nanoTime();
        for (int i = 0; i < quantia_veiculos; i++) {
            Veiculo veiculo = new Veiculo();
            avl.put(veiculo.getChassi(), veiculo);
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para inserir " + quantia_veiculos + " veículos em uma estrutura de Árvore Binária Balanceada:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de impressão em ordem crescente de número de chassi para uma estrutura de Vetor Ordenado.
     *
     * @param vetor estrutura de Vetor Ordenado a ser testada
     */
    public static void testarImpressaoPorOrdemChassiVetor(VetorOrdenado vetor) {
        long tempoInicio = System.nanoTime();
        vetor.impressaoEmOrdem();
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para imprimir os veículos em ordem crescente de número de chassi com Vetor Ordenado:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de impressão em ordem crescente de número de chassi para uma estrutura de Árvore Binária de Busca (ABB).
     *
     * @param abb estrutura de Árvore Binária de Busca a ser testada
     */
    public static void testarImpressaoPorOrdemChassiABB(ABB abb) {
        long tempoInicio = System.nanoTime();
        abb.impressaoEmOrdem();
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para imprimir os veículos em ordem crescente de número de chassi com ABB:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de impressão em ordem crescente de número de chassi para uma estrutura de Árvore AVL.
     *
     * @param avl estrutura de Árvore AVL a ser testada
     */
    public static void testarImpressaoPorOrdemChassiAVL(AVL avl) {
        long tempoInicio = System.nanoTime();
        avl.impressaoEmOrdem();
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para imprimir os veículos em ordem crescente de número de chassi com AVL:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de contagem de veículos da marca Ford em uma estrutura de Vetor Ordenado.
     *
     * @param vetor estrutura de Vetor Ordenado a ser testada
     */
    public static void testarContagemVeiculosFordVetor(VetorOrdenado vetor) {
        long tempoInicio = System.nanoTime();
        int contador = 0;
        for (Veiculo veiculo : vetor.values()) {
            if ("Ford".equals(veiculo.getMarca())) {
                contador++;
            }
        }
        System.out.println("Quantia de veículos da marca Ford: " + contador);
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para contar o número de veículos da marca Ford com Vetor Ordenado:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de contagem de veículos da marca Ford em uma estrutura de Árvore Binária de Busca (ABB).
     *
     * @param abb estrutura de Árvore Binária de Busca a ser testada
     */
    public static void testarContagemVeiculosFordABB(ABB abb) {
        long tempoInicio = System.nanoTime();
        int contador = 0;
        for (Veiculo veiculo : abb.values()) {
            if ("Ford".equals(veiculo.getMarca())) {
                contador++;
            }
        }
        System.out.println("Quantia de veículos da marca Ford: " + contador);
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para contar o número de veículos da marca Ford com ABB:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de contagem de veículos da marca Ford em uma estrutura de Árvore AVL.
     *
     * @param avl estrutura de Árvore AVL a ser testada
     */
    public static void testarContagemVeiculosFordAVL(AVL avl) {
        long tempoInicio = System.nanoTime();
        int contador = 0;
        for (Veiculo veiculo : avl.values()) {
            if ("Ford".equals(veiculo.getMarca())) {
                contador++;
            }
        }
        System.out.println("Quantia de veículos da marca Ford: " + contador);
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para contar o número de veículos da marca Ford com AVL:\033[0m " + tempo + " nanosegundos");
    }

    /**
     * Testa a operação de remoção de veículos com número de chassi igual ou inferior a 202050000 em uma estrutura de Vetor Ordenado.
     *
     * @param vetor estrutura de Vetor Ordenado a ser testada
     */
    public static void testarRemocaoVeiculosChassiVetor(VetorOrdenado vetor) {
        long tempoInicio = System.nanoTime();
        for (Veiculo veiculo : vetor.values()) {
            if (veiculo.getChassi() <= 202050000) {
                vetor.remove(veiculo.getChassi());
            }
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para remover todos os veículos com número de chassi igual ou inferior à 202050000 com Vetor Ordenado:\033[0m " + tempo + " nanosegundos");
        System.out.println("Veículos após remoção: ");
        vetor.impressaoEmOrdem();
    }

    /**
     * Testa a operação de remoção de veículos com número de chassi igual ou inferior a 202050000 em uma estrutura de Árvore Binária de Busca (ABB).
     *
     * @param abb estrutura de Árvore Binária de Busca a ser testada
     */
    public static void testarRemocaoVeiculosChassiABB(ABB abb) {
        long tempoInicio = System.nanoTime();
        for (Veiculo veiculo : abb.values()) {
            if (veiculo.getChassi() <= 202050000) {
                abb.remove(veiculo.getChassi());
            }
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para remover todos os veículos com número de chassi igual ou inferior à 202050000 com ABB:\033[0m " + tempo + " nanosegundos");
        System.out.println("Veículos após remoção: ");
        abb.impressaoEmOrdem();
    }

    /**
     * Testa a operação de remoção de veículos com número de chassi igual ou inferior a 202050000 em uma estrutura de Árvore AVL.
     *
     * @param avl estrutura de Árvore AVL a ser testada
     */
    public static void testarRemocaoVeiculosChassiAVL(AVL avl) {
        long tempoInicio = System.nanoTime();
        for (Veiculo veiculo : avl.values()) {
            if (veiculo.getChassi() <= 202050000) {
                avl.remove(veiculo.getChassi());
            }
        }
        long tempoFim = System.nanoTime();
        long tempo = tempoFim - tempoInicio;
        System.out.println("\033[36mTempo para remover todos os veículos com número de chassi igual ou inferior à 202050000 com AVL:\033[0m " + tempo + " nanosegundos");
        System.out.println("Veículos após remoção: ");
        avl.impressaoEmOrdem();
    }
}