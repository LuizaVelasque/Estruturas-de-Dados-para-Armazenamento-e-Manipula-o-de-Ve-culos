import java.util.*;

/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Implementação de uma Árvore Binária de Busca (ABB) que implementa a interface Map.
 * Esta implementação permite armazenar objetos do tipo Veiculo indexados por chaves do tipo Integer.
 */
public class ABB implements Map<Integer, Veiculo> {
    private Noh<Integer, Veiculo> raiz;
    private int tamanho;

    /**
     * Construtor da classe ABB.
     * @param tamanho Tamanho inicial da árvore.
     */
    public ABB(int tamanho){
        this.tamanho = tamanho;
        this.raiz = null;
    }

    /**
     * Insere um novo par chave-valor na árvore.
     * @param chave Chave do elemento a ser inserido.
     * @param valor Valor (Veiculo) a ser inserido.
     * @return O valor inserido.
     */
    @Override
    public Veiculo put(Integer chave, Veiculo valor) {
        raiz = inserir(raiz, chave, valor);
        tamanho++;
        return valor;
    }

    /**
     * Método auxiliar recursivo para inserir um novo nó na árvore.
     * @param noh Nó atual onde a inserção será realizada.
     * @param chave Chave do elemento a ser inserido.
     * @param valor Valor (Veiculo) a ser inserido.
     * @return O nó atualizado após a inserção.
     */
    private Noh<Integer, Veiculo> inserir(Noh<Integer, Veiculo> noh, Integer chave, Veiculo valor) {
        if (noh == null) {
            return new Noh<>(chave, valor);
        }
        if (chave < noh.chave) {
            noh.esquerdo = inserir(noh.esquerdo, chave, valor);
        } else if (chave > noh.chave) {
            noh.direito = inserir(noh.direito, chave, valor);
        } else {
            noh.valor = valor;
        }
        return noh;
    }

    /**
     * Obtém o valor associado à chave especificada.
     * @param chave Chave cujo valor associado será retornado.
     * @return Valor associado à chave ou null se a chave não estiver presente na árvore.
     */
    @Override
    public Veiculo get(Object chave) {
        return buscar(raiz, (Integer) chave);
    }

    /**
     * Método auxiliar recursivo para buscar um elemento na árvore.
     * @param noh Nó atual onde a busca será realizada.
     * @param chave Chave do elemento a ser buscado.
     * @return Valor associado à chave ou null se a chave não estiver presente na árvore.
     */
    private Veiculo buscar(Noh<Integer, Veiculo> noh, Integer chave) {
        if (noh == null || chave.equals(noh.chave)) {
            return (noh != null) ? noh.valor : null;
        }
        if (chave < noh.chave) {
            return buscar(noh.esquerdo, chave);
        } else {
            return buscar(noh.direito, chave);
        }
    }

    /**
     * Remove o elemento associado à chave especificada.
     * @param chave Chave do elemento a ser removido.
     * @return Valor associado à chave removida ou null se a chave não estiver presente na árvore.
     */
    @Override
    public Veiculo remove(Object chave) {
        Noh<Integer, Veiculo>[] resultado = remover(raiz, (Integer) chave);
        raiz = resultado[0];
        if (resultado[1] != null) tamanho--;
        return (resultado[1] != null) ? resultado[1].valor : null;
    }

    /**
     * Método auxiliar recursivo para remover um nó da árvore.
     * @param noh Nó atual onde a remoção será realizada.
     * @param chave Chave do elemento a ser removido.
     * @return Array com dois elementos: o primeiro é o nó atualizado e o segundo é o nó removido.
     */
    @SuppressWarnings("unchecked")
    private Noh<Integer, Veiculo>[] remover(Noh<Integer, Veiculo> noh, Integer chave) {
        if (noh == null) return new Noh[] { null, null };

        Noh<Integer, Veiculo>[] resultado;
        if (chave < noh.chave) {
            resultado = remover(noh.esquerdo, chave);
            noh.esquerdo = resultado[0];
        } else if (chave > noh.chave) {
            resultado = remover(noh.direito, chave);
            noh.direito = resultado[0];
        } else {
            if (noh.esquerdo == null) return new Noh[] { noh.direito, noh };
            if (noh.direito == null) return new Noh[] { noh.esquerdo, noh };
            Noh<Integer, Veiculo> temp = noh;
            noh = min(temp.direito);
            noh.direito = deletarMin(temp.direito);
            noh.esquerdo = temp.esquerdo;
            return new Noh[] { noh, temp };
        }
        return new Noh[] { noh, resultado[1] };
    }

    /**
     * Retorna o nó com o valor mínimo na árvore a partir de um nó dado.
     * @param noh Nó onde a busca pelo mínimo será iniciada.
     * @return Nó com o valor mínimo na subárvore.
     */
    private Noh<Integer, Veiculo> min(Noh<Integer, Veiculo> noh) {
        if (noh.esquerdo == null) return noh;
        return min(noh.esquerdo);
    }

    /**
     * Deleta o nó com o valor mínimo na árvore a partir de um nó dado.
     * @param noh Nó onde a remoção do mínimo será realizada.
     * @return Nó atualizado após a remoção do mínimo.
     */
    private Noh<Integer, Veiculo> deletarMin(Noh<Integer, Veiculo> noh) {
        if (noh.esquerdo == null) return noh.direito;
        noh.esquerdo = deletarMin(noh.esquerdo);
        return noh;
    }

    /**
     * Retorna o número de elementos na árvore.
     * @return Número de elementos na árvore.
     */
    @Override
    public int size() {
        return tamanho;
    }

    /**
     * Verifica se a árvore está vazia.
     * @return true se a árvore estiver vazia, false caso contrário.
     */
    @Override
    public boolean isEmpty() {
        return tamanho == 0;
    }

    /**
     * Verifica se a árvore contém a chave especificada.
     * @param chave Chave cuja presença será verificada na árvore.
     * @return true se a árvore contiver a chave, false caso contrário.
     */
    @Override
    public boolean containsKey(Object chave) {
        return get(chave) != null;
    }

    /**
     * Verifica se a árvore contém o valor especificado.
     * @param valor Valor cuja presença será verificada na árvore.
     * @return true se a árvore contiver o valor, false caso contrário.
     */
    @Override
    public boolean containsValue(Object valor) {
        for (Veiculo v : values()) {
            if (v.equals(valor)) return true;
        }
        return false;
    }

    /**
     * Remove todos os elementos da árvore, deixando-a vazia.
     */
    @Override
    public void clear() {
        raiz = null;
        tamanho = 0;
    }

    /**
     * Retorna uma coleção contendo todos os valores (Veiculo) presentes na árvore.
     * @return Coleção contendo todos os valores presentes na árvore.
     */
    @Override
    public Collection<Veiculo> values() {
        List<Veiculo> values = new ArrayList<>();
        emOrdem(raiz, values);
        return values;
    }

    /**
     * Método auxiliar recursivo para percorrer a árvore em ordem e adicionar os valores à lista.
     * @param noh Nó atual onde a operação será realizada.
     * @param values Lista onde os valores serão armazenados.
     */
    private void emOrdem(Noh<Integer, Veiculo> noh, List<Veiculo> values) {
        if (noh != null) {
            emOrdem(noh.esquerdo, values);
            values.add(noh.valor);
            emOrdem(noh.direito, values);
        }
    }

    /**
     * Imprime os valores da árvore em ordem.
     */
    public void impressaoEmOrdem() {
        emOrdemImpressao(this.raiz);
    }

    /**
     * Método auxiliar recursivo para imprimir os valores da árvore em ordem.
     * @param noh Nó atual onde a operação será realizada.
     */
    private void emOrdemImpressao(Noh<Integer, Veiculo> noh) {
        if (noh != null) {
            emOrdemImpressao(noh.esquerdo);
            System.out.println(noh.valor);
            emOrdemImpressao(noh.direito);
        }
    }

    @Override
    public Set<Entry<Integer, Veiculo>> entrySet() {
        throw new UnsupportedOperationException("Não implementado");
    }

    @Override
    public Set<Integer> keySet() {
        throw new UnsupportedOperationException("Não implementado");
    }

    @Override
    public void putAll(Map<? extends Integer, ? extends Veiculo> m) {
        throw new UnsupportedOperationException("Não implementado");
    }
}
